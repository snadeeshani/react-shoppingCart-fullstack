package com.virtusa.bakery.model;



import java.io.File;



import org.springframework.stereotype.Component;


public class Menu {

	
	
	private Integer id;
	private String title;
	private String img;
	private Integer price;
	private String info;
	private Boolean inCart;
	private Integer count;
	private Integer total;
	 
	 
	 
	 
	
	public Menu(Integer id, String title, String image1, Integer price, String info, Boolean inCart, Integer count,
			Integer total) {
		super();
		this.id = id;
		this.title = title;
		this.img = image1;
		this.price = price;
		this.info = info;
		this.inCart = inCart;
		this.count = count;
		this.total = total;
	}
	
	public Integer getId() {
		return id; 
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public Boolean getInCart() {
		return inCart;
	}
	public void setInCart(Boolean inCart) {
		this.inCart = inCart;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	

	
}
