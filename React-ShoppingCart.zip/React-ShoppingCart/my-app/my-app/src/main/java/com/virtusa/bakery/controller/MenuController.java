package com.virtusa.bakery.controller;



import java.io.IOException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.bakery.model.Menu;
import com.virtusa.bakery.service.MenuServiceImpl;

@RestController
@CrossOrigin()
@RequestMapping(value="/mybakery")

public class MenuController {
	

	@Autowired
	MenuServiceImpl menuService;
	
	@RequestMapping(value="/menu", method = RequestMethod.GET)
	public ArrayList<Menu> fetchMenuList() {
		try {
			return menuService.fetchMenuList();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
}
