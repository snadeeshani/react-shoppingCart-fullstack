package com.virtusa.bakery.model;

import javax.annotation.Generated;

public class Invoice {
	
	
	
	private Integer id;
	private String menu;
	private Integer price;
	private Integer quantity;
	private Integer total;
	
	
	
	
	public Invoice() {
		super();
	}
	
	
	public Invoice(Integer id, String menu, Integer price, Integer quantity, Integer total) {
		super();
		this.id = id;
		this.menu = menu;
		this.price = price;
		this.quantity = quantity;
		this.total = total;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	
	
}
