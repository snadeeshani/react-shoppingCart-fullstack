package com.virtusa.bakery.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.bakery.model.Invoice;
import com.virtusa.bakery.service.InvoiceServiceImpl;

@RestController
@RequestMapping(value="/mybakery")
public class InvoiceController {
	
	@Autowired
	InvoiceServiceImpl invoiceServiceImpl;

	@RequestMapping(value = "/invoice", method = RequestMethod.POST)
	public void saveOrder(@RequestBody List<Invoice> invoice)
	{
		invoiceServiceImpl.saveOrder(invoice);
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public ArrayList<List<Invoice>> fetchAll()
	{
		return invoiceServiceImpl.fetchAll();
	}
}
