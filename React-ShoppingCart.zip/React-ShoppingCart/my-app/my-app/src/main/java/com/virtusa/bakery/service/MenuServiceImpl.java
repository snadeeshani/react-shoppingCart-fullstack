package com.virtusa.bakery.service;



import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.virtusa.bakery.model.Menu;


@Service
public class MenuServiceImpl{

	public ArrayList<Menu> fetchMenuList() throws IOException {
		
		 	
		//load images from src/main/resources
		
		  File image1 = new File( "C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-1.png");
		  File image2 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-2.png");
		  File image3 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-3.png");
		  File image4 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-4.png");
		  File image5 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-5.jpg");
		  File image6 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-6.jpg");
		  File image7 = new File("C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-7.jpg");
		  File image8 = new File( "C:\\Users\\ssamaranayake\\Desktop\\my-app\\my-app\\src\\main\\resources\\images\\product-8.png");
		  
		
		  
		//Convert images to the byte array
		  byte[] imageContent1= FileUtils.readFileToByteArray(image1);
		  String endcodeimage1 = Base64.getEncoder().encodeToString(imageContent1);
		  
		  byte[] imageContent2= FileUtils.readFileToByteArray(image2);
		  String endcodeimage2= Base64.getEncoder().encodeToString(imageContent2);
		  
		  byte[] imageContent3= FileUtils.readFileToByteArray(image3);
		  String endcodeimage3 = Base64.getEncoder().encodeToString(imageContent3);
		  
		  byte[] imageContent4= FileUtils.readFileToByteArray(image4);
		  String endcodeimage4 = Base64.getEncoder().encodeToString(imageContent4);
		  
		  byte[] imageContent5= FileUtils.readFileToByteArray(image5);
		  String endcodeimage5 = Base64.getEncoder().encodeToString(imageContent5);
		  
		  byte[] imageContent6= FileUtils.readFileToByteArray(image6);
		  String endcodeimage6 = Base64.getEncoder().encodeToString(imageContent6);
		  
		  byte[] imageContent7= FileUtils.readFileToByteArray(image7);
		  String endcodeimage7 = Base64.getEncoder().encodeToString(imageContent7);
		  
		  byte[] imageContent8= FileUtils.readFileToByteArray(image8);
		  String endcodeimage8 = Base64.getEncoder().encodeToString(imageContent8);
		  
		  
		  //Assign information to the menu
		  Menu menu1= new Menu(1, "Ham & Cheese with Mustard SW", endcodeimage1,100, " It is made by putting cheese and sliced ham between two slices of bread. The bread is sometimes buttered and/or toasted. Vegetables like lettuce, tomato, onion or pickle slices also be included.", false, 0, 0);
		  Menu menu2= new Menu(2, "Spicy Polos & Cheese SW", endcodeimage2,160, " It is made by putting spicy polos between two slices of bread. The bread is sometimes buttered and/or toasted. Vegetables like lettuce, tomato, onion or pickle slices also be included.", false, 0, 0);
		  Menu menu3= new Menu(3, "Tuna & Cucumber SW", endcodeimage3,80, "Spread mayonnaise on one side of each bread slice. Then layer the sandwich cucumber, tuna, and then cucumber.", false, 0, 0);
		  Menu menu4= new Menu(4, "Pol Sambol with Fried Egg & Cheese SW", endcodeimage4,180, "Spread mayonnaise on one side of each bread slice. Then layer the sandwich pol sambol and fried egg.", false, 0, 0);
		  Menu menu5= new Menu(5, "Honey Roasted Chicken", endcodeimage5,240, "It's a grilled chicken with homemade honey mustard sauce recipe.", false, 0, 0);
		  Menu menu6= new Menu(6, "Smoked Chicken Sandwich", endcodeimage6,170, " Few slices of ham and smoked chicken to the bottom part of a toasted bun along with a slice of each mozzarella and pepper jack.", false, 0, 0);
		  Menu menu7= new Menu(7, "Jaffna Style Prawn", endcodeimage7,300, "It is made by jaffna style spicy prawns between toasted slices of bread. ", false, 0, 0);
		  Menu menu8= new Menu(8, "​Chicken Tikka with Raita", endcodeimage8,200, "Chicken Tikka Sandwich-Mashed chicken tikka mixed with capsicum green chutney with mayonnaise and stuffed in sandwich and grilled taste. ", false, 0, 0);
		  
		  
		  //Put all the objects in to an arraylist
		  ArrayList<Menu> menulist= new ArrayList<Menu>();
		  menulist.add(menu1);
		  menulist.add(menu2);
		  menulist.add(menu3);
		  menulist.add(menu4);
		  menulist.add(menu5);
		  menulist.add(menu6);
		  menulist.add(menu7);
		  menulist.add(menu8);
		  
		  return menulist;
		 
	}

	
}
