package com.virtusa.bakery.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.bakery.model.Invoice;

@Service
public class InvoiceServiceImpl {
	
	ArrayList<List<Invoice>> order= new ArrayList<List<Invoice>>();
	
	public void saveOrder(List<Invoice> invoice)
	{
		
		
		order.add(invoice);
		
	}
	
	public ArrayList<List<Invoice>> fetchAll()
	{
		return order;
	}
	
}
