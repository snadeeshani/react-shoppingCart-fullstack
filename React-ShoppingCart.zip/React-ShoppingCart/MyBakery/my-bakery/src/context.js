import React, {Component} from 'react';
import {storeProducts, detailProduct} from './data';
import axios from 'axios';

const ProductContext= React.createContext();


class ProductProvider extends Component{
    state={
        products: [],
        detailProduct: detailProduct,
        cart: [],
        modalOpen: false,
        modalProduct: detailProduct,
        cartSubTotal: 0,
        cartTax: 0,
        cartTotal: 0
    };
    /*To get values of object (not references) */
    componentDidMount(){
        this.storeProducts();
    };
    /* To assign the values in data.js */
    storeProducts = () =>{
        // let tempProduct = [];
        // storeProducts.forEach(item => {
        //     const singleItem= {...item};
        //     tempProduct = [...tempProduct, singleItem];
        // });
        // this.setState(()=>{
        //     return{products: tempProduct};
        // });
        axios
        .get("http://localhost:8080/mybakery/menu")
        .then(response => {
            let storedproducts = response.data;
            console.log(storedproducts);
            this.setState(() => {
                return { products: storedproducts };
            });
        })
        .catch(error => console.log(error));
    };
    getItem = (id) =>{
        const product = this.state.products.find(item => item.id ===id);
        return product;
    };
    /* catch the return object from getItem */
    handleDetail = (id) =>{
       const product = this.getItem(id);
       this.setState(() => {
           return {detailProduct: product};
       });

        
    };
    addToCart = (id) =>{
        let tempProduct = [...this.state.products];
        const index = tempProduct.indexOf(this.getItem(id));
        const product = tempProduct[index];
        product.inCart = true;
        product.count = 1;
        const price = product.price;
        product.total =price;

        this.setState(() => {
            return {products :tempProduct, cart:[...this.state.cart, product]};    
        }, ()=> {
            this.addTotals();
        });
    };
    /**For menu popup window*/
    openModel = id =>{
        const product = this.getItem(id);
        this.setState(()=>{
            return {modalProduct: product, modalOpen:true}
        });
    };
    /*To close the popup window */
    closeModal = () =>{
        this.setState(() =>{
            return {modalOpen:false}
        });
    };
    /* For increase the number of quantity */
    increment = id => {
        let tempCart = [...this.state.cart];
        const selectedProduct = tempCart.find(item=>item.id === id);

        const index = tempCart.indexOf(selectedProduct);
        const product = tempCart[index];
        product.count = product.count + 1 ;
        product.total = product.count * product.price;

        this.setState( () => {
            return { cart: [...tempCart] };
        },
        () =>{
            this.addTotals();
        }
        );
    };
     /* For reduce the number of quantity */
     decrement = id => {
        let tempCart = [...this.state.cart];
        const selectedProduct = tempCart.find(item => item.id === id);

        const index = tempCart.indexOf(selectedProduct);
        const product = tempCart[index];
        product.count = product.count - 1 ;
        
        if(product.count === 0){
            this.removeItem(id)
        }
        else{
            product.total = product.count * product.price;
            this.setState( () => {
                return {cart :[...tempCart]};
            },
            () =>{
                this.addTotals();
            }
            );
        }
    };

    /*For remove the item */
    removeItem = id =>{
        let tempProducts = [...this.state.products];
        let tempCart = [...this.state.cart];
        tempCart = tempCart.filter(item => item.id !== id);
        const index= tempProducts.indexOf(this.getItem(id));
        let removedProduct = tempProducts[index];
        removedProduct.inCart = false;
        removedProduct.count = 0;
        removedProduct.total = 0;

        this.setState( () => {
            return {
                cart: [...tempCart],
                products: [...tempProducts]
            };
        },
        () =>{
            this.addTotals();
        }
        );

    };

    /*For clear the cart*/
    clearCart = () =>{
       this.setState(() => {
           return {cart: []};
       }, () => {
           this.storeProducts();
           this.addTotals();
       });
    };
    /*To add all prices */
    addTotals = () => {
        let subTotal = 0;
        this.state.cart.map(item => (subTotal += item.total));
        const tempTax = subTotal * 0.1;
        const tax = parseFloat(tempTax.toFixed(2));
        const total = subTotal + tax
        this.setState(() => {
            return{
                cartSubTotal: subTotal,
                cartTax: tax,
                cartTotal: total
            };
        } );
    };

    /* Post API */
    submitOrder = e => {
        e.preventDefault()
        console.log(this.state)
        axios.post("http://localhost:8080/mybakery/invoice",this.state)
        .then (response => {
            console.log(response)
        })
        .catch(error =>{
            console.log(error);
        })

    };
    render(){
        return(
            <ProductContext.Provider value={{
                    ...this.state,
                    handleDetail: this.handleDetail,
                    addToCart: this.addToCart,
                    openModal: this.openModel,
                    closeModal:this.closeModal,
                    increment: this.increment,
                    decrement: this.decrement,
                    removeItem:this.removeItem,
                    clearCart: this.clearCart
            }}>
               
                {this.props.children}
            </ProductContext.Provider>
        );
    }
}

const ProductConsumer = ProductContext.Consumer;

export {ProductProvider, ProductConsumer};