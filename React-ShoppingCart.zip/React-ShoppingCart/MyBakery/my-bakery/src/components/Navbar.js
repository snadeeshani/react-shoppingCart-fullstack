import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import logo from '../logo.svg';
import {ButtonContainer} from './Button';



export default class Navbar extends Component{
    render(){
        return(
             <nav className="navbar navbar-expand-sm bg-info navbar-dark px-sm-5 ">
                 {/*https://www.iconfinder.com/icons/379396/shop_icon */}
                <Link to ='/' >
                    <img src={logo} alt="bakery" className="navbar-brand"/>
                </Link>

                <ul className="navbar-nav align-item-center">
                    <li className="nav-item ml-5">
                        <Link to= '/' className="nav-link">
                           <h2>My Bakery</h2> 
                        </Link>
                    </li>
                    <li className="nav-item ml-5">
                        <Link to= '/' className="nav-link">
                           <h5>Menu</h5> 
                        </Link>
                    </li>
                    <li className="nav-item ml-5">
                        <Link to= '/contactUs' className="nav-link">
                           <h5>Contact Us</h5> 
                        </Link>
                    </li>
                </ul> 
                
                <Link to='/cart' className="ml-auto">
                <ButtonContainer>
                        <span className="mr-2">
                        <i className="fa fa-cart-plus"/>
                        </span>
                        My Cart
                    </ButtonContainer>
                                   
                </Link>   
            </nav>
            
        );
    }
}
