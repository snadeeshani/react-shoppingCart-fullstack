// import React, {Component} from 'react';
// import {Link} from 'react-router-dom';
// import {ButtonContainer} from './Button';

// export default class Pay extends Component{
//     render(){
//         return(
//             <div>
//                 <Link to='/'>
//                     <ButtonContainer >
//                                                 Pay
//                     </ButtonContainer>
//                 </Link>
//             </div>
//         )
//     }
// }